import java.rmi.Naming;
import java.util.Scanner;

public class AgenciaClient {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
            int option;
            String idConta= "1234";
            double valor;
         try {
            String serverAddress = "179.219.161.158"; // IP do servidor
            String serverName = "BancoServer";        // Nome do serviço

            BancoInterface banco = (BancoInterface) Naming.lookup("rmi://" + serverAddress + ":1099/" + serverName);
            banco.abrirConta(idConta);
            banco.depositar("1234", 200);
            do {
                System.out.println("\n--- Menu de Operações ---");
                System.out.println("1. Abrir Conta");
                System.out.println("2. Fechar Conta");
                System.out.println("3. Depósito");
                System.out.println("4. Retirada");
                System.out.println("5. Consulta de Saldo");
                System.out.println("0. Sair");
                System.out.print("Escolha uma opção: ");
                option = scanner.nextInt();
                System.out.println();
                if(option!=0){
                    idConta = getId(scanner);
                }

                switch (option) {
                    case 1:
                    banco.abrirConta(idConta);
                        break;
                    case 2:
                        banco.fecharConta(idConta);
                        break;
                    case 3:
                    valor = getValor(scanner, "deposito");
                    banco.depositar(idConta, valor);
                        break;
                    case 4:
                    valor = getValor(scanner, "retirada");
                    banco.sacar(idConta, valor);
                        break;
                    case 5:
                        valor= banco.consultarSaldo(idConta);
                        System.out.println(valor);
                        break;
                    case 0:
                        System.out.println("Saindo...");
                        break;
                    default:
                        System.out.println("Opção inválida! Tente novamente.");
                }
            } while (option != 0);
            scanner.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static String getId(Scanner scanner){
        System.out.println("digite o id da conta");
        scanner.nextLine();
        String idConta = scanner.nextLine();
        return idConta;
    }
    public static int getValor(Scanner scanner, String operacao){
        System.out.println("digite o valor da operacao de " +operacao);
        int valor = scanner.nextInt();
        return valor;
    }

}
